export class TestDetails {
  category = 'Test';
  test: boolean;
}
